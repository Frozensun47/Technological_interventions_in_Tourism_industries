PROJECT : Technological Interventions in Tourism Industry
This folder contains :
	-python code file.
	-dataset csv file of monthly tourist footfalls in india from 2002 to 2018.
	-readme file.


To run the program follow thw following steps:

1)right click the folder 
	-open in vscode
2)open the python file
3)(required only once) open terminal
	(required python3) if you dont have then please install.
	type:-
	pip install tensorflow
	pip install numpy
	pip install pandas
	pip install matplotlib
	pip install sklearn
4)run the python file.
5)  ignore cudart64_110.dll error if it appears.
109460.6580